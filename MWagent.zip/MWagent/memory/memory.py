# 后续检查A Survey on the Memory Mechanism of Large Language Model based Agents
# 这篇文章来完善

class Memory:
    def __init__(self):
        self.memories = []  # List of strings for simplicity

    def add_memory(self, reflection):
        self.memories.append(reflection)

    def retrieve(self, keyword):
        # Simple keyword search retrieval
        return [mem for mem in self.memories if keyword in mem]