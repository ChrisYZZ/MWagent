# Delivery Agent的个性化记忆注入prompt
# EconAgent的经济决策模拟

import os
from openai import OpenAI  # Requires 'pip install openai'

class DeliveryAgent:
    def __init__(self, memory):
        self.memory = memory
        self.prompt_template = self.load_prompt()
        # Set DeepSeek API client (compatible with OpenAI SDK)
        #api_key = os.getenv("DEEPSEEK_API_KEY")
        api_key = ""
        if not api_key:
            raise ValueError("DEEPSEEK_API_KEY environment variable not set.")
        self.client = OpenAI(
            base_url="https://api.deepseek.com",
            api_key=api_key
        )

    def load_prompt(self):
        # Load prompt from file
        prompt_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "prompts", "decision_prompt.txt")
        with open(prompt_path, "r") as f:
            return f.read()

    def decide(self, order):
        # Retrieve relevant memories
        relevant_memories = self.memory.retrieve(order['location'])
        
        # Format prompt with order and memories
        prompt = self.prompt_template.format(
            order=order,
            memories="\n".join(relevant_memories) if relevant_memories else "No prior memories."
        )
        print(f"LLM Prompt: {prompt}")  # For debugging
        
        try:
            # Call DeepSeek API via OpenAI-compatible client
            response = self.client.chat.completions.create(
                model="deepseek-chat",  # Or 'deepseek-coder' for code-related tasks
                messages=[
                    {"role": "system", "content": "You are a helpful delivery agent optimizer."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=150,
                temperature=0.7
            )
            llm_output = response.choices[0].message.content.strip()
            print(f"LLM Response: {llm_output}")  # For debugging
            
            # Parse the response: Assume format "Decision: accept/reject\nReasoning: ..."
            lines = llm_output.split("\n")
            decision_line = next((line for line in lines if line.startswith("Decision:")), None)
            reasoning = "\n".join(lines[1:]) if len(lines) > 1 else "No reasoning provided."
            
            if decision_line:
                decision = decision_line.split(":")[1].strip().lower()
                if decision not in ["accept", "reject"]:
                    raise ValueError("Invalid decision from LLM.")
            else:
                raise ValueError("No decision in LLM response.")
        
        except Exception as e:
            print(f"LLM Error: {e}. Falling back to rule-based decision.")
            # Fallback to simple rule if API fails
            if order['value'] > 15 and order['distance'] < 5:
                decision = "accept"
                reasoning = "High value and short distance, good efficiency (fallback)."
            else:
                decision = "reject"
                reasoning = "Low value or long distance, not worth it (fallback)."
        
        return decision, reasoning