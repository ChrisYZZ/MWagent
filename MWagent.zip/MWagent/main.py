import random
from env.environment import Environment
from agents.delivery_agent import DeliveryAgent
from memory.memory import Memory
from evaluation import evaluate_performance

def main():
    # Initialize components
    env = Environment()
    memory = Memory()
    agent = DeliveryAgent(memory)

    # Simulation loop: run for 5 steps as example
    total_orders_handled = 0
    total_revenue = 0
    total_time = 0

    for step in range(5):  # Debuggable: adjust steps
        print(f"\n--- Simulation Step {step + 1} ---")
        
        # Generate order from environment
        order = env.generate_order()
        print(f"Generated Order: {order}")
        
        # Agent makes decision
        decision, reasoning = agent.decide(order)
        print(f"Agent Decision: {decision}")
        print(f"Reasoning: {reasoning}")
        
        if decision == "accept":
            # Simulate delivery: assume random time and revenue based on order
            delivery_time = random.randint(10, 30)  # minutes
            revenue = order['value']
            total_orders_handled += 1
            total_revenue += revenue
            total_time += delivery_time
            
            # Update memory with reflection
            reflection = f"Accepted order at {order['location']}, revenue {revenue}, time {delivery_time}"
            memory.add_memory(reflection)
            print(f"Memory Updated: {reflection}")
    
    # Evaluate performance
    metrics = evaluate_performance(total_orders_handled, total_revenue, total_time)
    print("\n--- Final Evaluation ---")
    for key, value in metrics.items():
        print(f"{key}: {value}")

if __name__ == "__main__":
    main()