# 评估指标来源Software Agent Simulation Design on the Efficiency of Food Delivery

def evaluate_performance(orders_handled, total_revenue, total_time):
    if orders_handled == 0:
        return {
            "Total Orders Handled": 0,
            "Total Revenue": 0,
            "Average Efficiency (Time per Order)": "N/A"
        }
    
    avg_time = total_time / orders_handled
    return {
        "Total Orders Handled": orders_handled,
        "Total Revenue": total_revenue,
        "Average Efficiency (Time per Order)": f"{avg_time:.2f} minutes"
    }