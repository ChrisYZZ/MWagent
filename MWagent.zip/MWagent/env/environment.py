# 订单生成借鉴GITM开放世界环境模拟思路https://arxiv.org/pdf/2305.17144
# 应该可以生成更复杂中间路径，需要MW来检查sim设置

import random

class Environment:
    def __init__(self):
        self.locations = ["Downtown", "Suburb", "Campus", "Industrial"]  # Example locations
        self.values = [10, 15, 20, 25]  # Order values in dollars

    def generate_order(self):
        # Generate a random order
        order = {
            "location": random.choice(self.locations),
            "value": random.choice(self.values),
            "distance": random.randint(1, 10),  # km
            "time_window": random.randint(15, 45)  # minutes
        }
        return order